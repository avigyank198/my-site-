# ⚡ AKINU .AI — Mobile App

A powerful AI assistant for complex tasks, built with **React Native + Expo**.
Runs on both **Android** and **iOS**.

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn
- [Expo Go](https://expo.dev/go) app on your phone (for instant preview)
- OR Android Studio / Xcode for emulator

### 1. Install dependencies
```bash
npm install
```

### 2. Start the app
```bash
npx expo start
```

### 3. Run on your device
- **Physical phone**: Scan the QR code with the Expo Go app
- **Android emulator**: Press `a` in the terminal
- **iOS simulator**: Press `i` in the terminal (Mac only)

---

## 📦 Build for Production

### Android APK
```bash
npx expo build:android
# or with EAS Build (recommended):
npx eas build --platform android
```

### iOS IPA
```bash
npx eas build --platform ios
```

### Both platforms
```bash
npx eas build --platform all
```

---

## 🗂 Project Structure

```
AkinuAI/
├── App.js                        # Entry point
├── app.json                      # Expo config
├── src/
│   ├── constants/index.js        # Colors, prompts, data
│   ├── components/index.js       # Reusable UI components
│   ├── navigation/AppNavigator.js # Tab + Stack navigation
│   └── screens/
│       ├── HomeScreen.js         # Home dashboard
│       ├── ChatScreen.js         # AI chat interface
│       ├── ExploreScreen.js      # Browse capabilities
│       └── SettingsScreen.js     # User settings
```

---

## ✨ Features

- ⚡ **AI Chat** — Full conversation with AKINU .AI (Claude claude-sonnet-4-6)
- 🌐 **Build Websites** — Generate complete HTML/CSS/JS
- 💻 **Write Code** — Any language, any task
- 🎨 **Design Help** — Color palettes, UI guides
- 📋 **Copy Code** — One-tap copy on all code blocks
- 🔭 **Explore** — Browse 20+ task categories
- ⚙️ **Settings** — Profile, notifications, theme

---

## 🔧 Customization

Edit `src/constants/index.js` to change:
- `COLORS` — app-wide color theme
- `QUICK_ACTIONS` — home screen quick tasks
- `EXPLORE_CATEGORIES` — explore screen content
- `SYSTEM_PROMPT` — AKINU's personality & behavior

---

## 📱 Publishing to App Stores

1. Create an [Expo account](https://expo.dev)
2. Install EAS CLI: `npm install -g eas-cli`
3. Configure: `eas build:configure`
4. Build & submit: `eas submit`

---

Built with ❤️ using React Native + Expo + Claude API
