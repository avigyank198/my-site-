import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Switch } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { COLORS } from '../constants';

const SETTINGS_ROWS = [
  { icon: '🔔', label: 'Notifications', type: 'toggle' },
  { icon: '🎨', label: 'Theme', value: 'Dark', type: 'nav' },
  { icon: '🌍', label: 'Language', value: 'English', type: 'nav' },
  { icon: '🔐', label: 'Privacy & Security', type: 'nav' },
  { icon: '💳', label: 'Subscription', value: 'Pro', type: 'nav' },
  { icon: '⭐', label: 'Rate AKINU .AI', type: 'nav' },
  { icon: '📢', label: 'Share with Friends', type: 'nav' },
  { icon: 'ℹ️', label: 'About', value: 'v1.0.0', type: 'nav' },
];

export default function SettingsScreen() {
  const [notifs, setNotifs] = React.useState(true);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Profile card */}
      <View style={styles.profileCard}>
        <LinearGradient colors={['#7c3aed', '#a78bfa']} style={styles.avatar}>
          <Text style={{ fontSize: 34 }}>⚡</Text>
        </LinearGradient>
        <Text style={styles.profileName}>AKINU .AI</Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>⭐ Pro Member</Text>
        </View>
        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statNum}>47</Text>
            <Text style={styles.statLabel}>Tasks</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNum}>12</Text>
            <Text style={styles.statLabel}>Websites</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNum}>∞</Text>
            <Text style={styles.statLabel}>Messages</Text>
          </View>
        </View>
      </View>

      {/* Settings list */}
      <View style={styles.settingsList}>
        {SETTINGS_ROWS.map((row, i) => (
          <TouchableOpacity
            key={i}
            style={[styles.settingsRow, i < SETTINGS_ROWS.length - 1 && styles.rowBorder]}
            activeOpacity={row.type === 'toggle' ? 1 : 0.7}
          >
            <Text style={styles.rowIcon}>{row.icon}</Text>
            <Text style={styles.rowLabel}>{row.label}</Text>
            <View style={styles.rowRight}>
              {row.type === 'toggle' ? (
                <Switch
                  value={notifs}
                  onValueChange={setNotifs}
                  trackColor={{ false: COLORS.border, true: COLORS.purpleDark }}
                  thumbColor={COLORS.white}
                />
              ) : (
                <>
                  {row.value && <Text style={styles.rowValue}>{row.value}</Text>}
                  <Text style={styles.rowArrow}>›</Text>
                </>
              )}
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.logoutBtn} activeOpacity={0.7}>
        <Text style={styles.logoutText}>Sign Out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 20, paddingBottom: 48 },
  profileCard: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  profileName: { fontSize: 18, fontWeight: '700', color: COLORS.white, marginBottom: 8 },
  badge: {
    backgroundColor: COLORS.purpleDeep,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    marginBottom: 20,
  },
  badgeText: { fontSize: 12, color: COLORS.purple, fontWeight: '600' },
  statsRow: { flexDirection: 'row', alignItems: 'center' },
  stat: { alignItems: 'center', flex: 1 },
  statNum: { fontSize: 20, fontWeight: '700', color: COLORS.white },
  statLabel: { fontSize: 11, color: COLORS.textDim, marginTop: 2 },
  statDivider: { width: 1, height: 28, backgroundColor: COLORS.border },
  settingsList: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 16,
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    gap: 14,
  },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  rowIcon: { fontSize: 20 },
  rowLabel: { flex: 1, fontSize: 14, color: COLORS.textSecondary },
  rowRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowValue: { fontSize: 13, color: COLORS.textDim },
  rowArrow: { fontSize: 20, color: COLORS.textDim },
  logoutBtn: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: '#3a1a1a',
    borderRadius: 14,
    padding: 15,
    alignItems: 'center',
  },
  logoutText: { fontSize: 14, color: '#f87171', fontWeight: '600' },
});
