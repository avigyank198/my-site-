import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, EXPLORE_CATEGORIES } from '../constants';

export default function ExploreScreen({ navigation }) {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Text style={styles.title}>Explore</Text>
      <Text style={styles.subtitle}>Discover what AKINU .AI can do</Text>

      {EXPLORE_CATEGORIES.map((cat, i) => (
        <View key={i} style={styles.category}>
          <View style={styles.catHeader}>
            <Text style={styles.catIcon}>{cat.icon}</Text>
            <Text style={styles.catTitle}>{cat.title}</Text>
          </View>
          <View style={styles.chips}>
            {cat.items.map((item, j) => (
              <TouchableOpacity
                key={j}
                style={styles.chip}
                onPress={() => navigation.navigate('Chat', { initialPrompt: `Help me with: ${item}` })}
                activeOpacity={0.7}
              >
                <Text style={styles.chipText}>{item}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ))}

      {/* Banner */}
      <View style={styles.banner}>
        <Text style={styles.bannerIcon}>🚀</Text>
        <View style={{ flex: 1 }}>
          <Text style={styles.bannerTitle}>Unlimited Tasks</Text>
          <Text style={styles.bannerSub}>Pro Plan — Upgrade for more power</Text>
        </View>
        <TouchableOpacity style={styles.bannerBtn}>
          <Text style={styles.bannerBtnText}>Upgrade</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 20, paddingBottom: 40 },
  title: { fontSize: 22, fontWeight: '700', color: COLORS.white, marginBottom: 4 },
  subtitle: { fontSize: 13, color: COLORS.textDim, marginBottom: 24 },
  category: { marginBottom: 24 },
  catHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 12 },
  catIcon: { fontSize: 20 },
  catTitle: { fontSize: 15, fontWeight: '600', color: COLORS.textSecondary },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  chipText: { fontSize: 12, color: COLORS.purple },
  banner: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.purpleDark,
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginTop: 8,
  },
  bannerIcon: { fontSize: 24 },
  bannerTitle: { fontSize: 14, fontWeight: '600', color: COLORS.white },
  bannerSub: { fontSize: 11, color: COLORS.textDim, marginTop: 2 },
  bannerBtn: {
    backgroundColor: COLORS.purpleDark,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  bannerBtnText: { fontSize: 12, color: COLORS.white, fontWeight: '600' },
});
