import React, { useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, QUICK_ACTIONS } from '../constants';
import { QuickActionCard, SectionLabel } from '../components';

export default function HomeScreen({ navigation }) {
  const [recentChats, setRecentChats] = React.useState([]);

  // Reload recent chats every time this screen is focused
  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        try {
          const raw = await AsyncStorage.getItem('recent_chats');
          if (raw) setRecentChats(JSON.parse(raw));
        } catch (_) {}
      };
      load();
    }, [])
  );

  const handleQuickAction = (action) => {
    navigation.navigate('Chat', { initialPrompt: action.prompt });
  };

  const formatTime = (ts) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Hero */}
      <LinearGradient colors={['#1a0a3a', '#0d0d22']} style={styles.hero}>
        <View style={styles.heroBubble} />
        <Text style={styles.heroEyebrow}>Ready to build ✨</Text>
        <Text style={styles.heroTitle}>What can AKINU{'\n'}build for you? ⚡</Text>
        <Text style={styles.heroSub}>Your AI for complex tasks</Text>
      </LinearGradient>

      {/* Search bar */}
      <TouchableOpacity
        style={styles.searchBar}
        onPress={() => navigation.navigate('Chat', {})}
        activeOpacity={0.8}
      >
        <Text style={styles.searchIcon}>🔍</Text>
        <Text style={styles.searchPlaceholder}>Ask AKINU anything...</Text>
      </TouchableOpacity>

      {/* Quick actions */}
      <View style={styles.section}>
        <SectionLabel text="Quick Actions" />
        <View style={styles.qaGrid}>
          {QUICK_ACTIONS.map((a, i) => (
            <QuickActionCard
              key={i}
              icon={a.icon}
              label={a.label}
              onPress={() => handleQuickAction(a)}
            />
          ))}
        </View>
      </View>

      {/* Recent chats */}
      {recentChats.length > 0 && (
        <View style={styles.section}>
          <SectionLabel text="Recent Chats" />
          {recentChats.slice(0, 5).map((r, i) => (
            <TouchableOpacity
              key={i}
              style={styles.recentCard}
              onPress={() => navigation.navigate('Chat', {})}
              activeOpacity={0.7}
            >
              <LinearGradient colors={['#4c1d95', '#7c3aed']} style={styles.recentIcon}>
                <Text style={{ fontSize: 16 }}>⚡</Text>
              </LinearGradient>
              <View style={styles.recentInfo}>
                <Text style={styles.recentTitle} numberOfLines={1}>{r.title}</Text>
                <Text style={styles.recentTime}>{formatTime(r.timestamp)}</Text>
              </View>
              <Text style={styles.recentArrow}>›</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  content: { paddingBottom: 32 },
  hero: {
    padding: 24,
    paddingTop: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  heroBubble: {
    position: 'absolute',
    top: -30,
    right: -30,
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#7c3aed22',
  },
  heroEyebrow: {
    fontSize: 12,
    color: COLORS.purple,
    letterSpacing: 1,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.white,
    lineHeight: 32,
    marginBottom: 6,
  },
  heroSub: { fontSize: 13, color: COLORS.textMuted },
  searchBar: {
    marginHorizontal: 16,
    marginTop: 16,
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  searchIcon: { fontSize: 16 },
  searchPlaceholder: { color: COLORS.textDim, fontSize: 14 },
  section: { paddingHorizontal: 16, marginTop: 20 },
  qaGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -4,
  },
  recentCard: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  recentIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  recentInfo: { flex: 1 },
  recentTitle: { fontSize: 13, color: COLORS.textSecondary, fontWeight: '500' },
  recentTime: { fontSize: 11, color: COLORS.textDim, marginTop: 2 },
  recentArrow: { fontSize: 18, color: COLORS.textDim },
});
