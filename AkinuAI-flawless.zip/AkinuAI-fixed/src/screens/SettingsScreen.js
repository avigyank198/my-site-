import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Switch, Alert, Share } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS } from '../constants';

const NOTIFS_KEY = 'setting_notifications';

export default function SettingsScreen() {
  const [notifs, setNotifs] = useState(true);
  const [stats, setStats] = useState({ tasks: 0, chats: 0 });

  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        try {
          // Load notification preference
          const savedNotifs = await AsyncStorage.getItem(NOTIFS_KEY);
          if (savedNotifs !== null) setNotifs(JSON.parse(savedNotifs));

          // Load real stats
          const raw = await AsyncStorage.getItem('recent_chats');
          const chats = raw ? JSON.parse(raw) : [];
          let totalMsgs = 0;
          for (const chat of chats.slice(0, 20)) {
            const msgRaw = await AsyncStorage.getItem(`chat_messages_${chat.id}`);
            if (msgRaw) {
              const msgs = JSON.parse(msgRaw);
              totalMsgs += msgs.filter(m => m.role === 'user').length;
            }
          }
          setStats({ tasks: totalMsgs, chats: chats.length });
        } catch (_) {}
      };
      load();
    }, [])
  );

  const handleNotifsToggle = async (value) => {
    setNotifs(value);
    try {
      await AsyncStorage.setItem(NOTIFS_KEY, JSON.stringify(value));
    } catch (_) {}
  };

  const handleClearHistory = () => {
    Alert.alert(
      'Clear Chat History',
      'This will permanently delete all saved conversations. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear All',
          style: 'destructive',
          onPress: async () => {
            try {
              const raw = await AsyncStorage.getItem('recent_chats');
              const chats = raw ? JSON.parse(raw) : [];
              const keys = chats.map(c => `chat_messages_${c.id}`);
              await AsyncStorage.multiRemove([...keys, 'recent_chats']);
              setStats({ tasks: 0, chats: 0 });
              Alert.alert('Done', 'Chat history cleared.');
            } catch (_) {
              Alert.alert('Error', 'Could not clear history.');
            }
          },
        },
      ]
    );
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: 'Check out AKINU .AI — a powerful AI assistant for complex tasks! ⚡',
      });
    } catch (_) {}
  };

  const handleRate = () => {
    Alert.alert('Rate AKINU .AI', 'Thank you! Rating will open in the App Store on a real device.');
  };

  const handleAbout = () => {
    Alert.alert(
      'AKINU .AI v1.0.0',
      'Powered by Claude (Anthropic)\n\nBuilt with React Native & Expo.\n\nFor production use, route API calls through your own backend.'
    );
  };

  const SETTINGS_ROWS = [
    { icon: '🔔', label: 'Notifications', type: 'toggle' },
    { icon: '🗑️', label: 'Clear Chat History', type: 'action', onPress: handleClearHistory, danger: true },
    { icon: '⭐', label: 'Rate AKINU .AI', type: 'action', onPress: handleRate },
    { icon: '📢', label: 'Share with Friends', type: 'action', onPress: handleShare },
    { icon: 'ℹ️', label: 'About', value: 'v1.0.0', type: 'action', onPress: handleAbout },
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {/* Profile card */}
      <View style={styles.profileCard}>
        <LinearGradient colors={['#7c3aed', '#a78bfa']} style={styles.avatar}>
          <Text style={{ fontSize: 34 }}>⚡</Text>
        </LinearGradient>
        <Text style={styles.profileName}>AKINU .AI</Text>
        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statNum}>{stats.tasks}</Text>
            <Text style={styles.statLabel}>Tasks</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNum}>{stats.chats}</Text>
            <Text style={styles.statLabel}>Chats</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.stat}>
            <Text style={styles.statNum}>∞</Text>
            <Text style={styles.statLabel}>Messages</Text>
          </View>
        </View>
      </View>

      {/* Settings list */}
      <View style={styles.settingsList}>
        {SETTINGS_ROWS.map((row, i) => (
          <TouchableOpacity
            key={i}
            style={[styles.settingsRow, i < SETTINGS_ROWS.length - 1 && styles.rowBorder]}
            onPress={row.type === 'action' ? row.onPress : undefined}
            activeOpacity={row.type === 'toggle' ? 1 : 0.7}
          >
            <Text style={styles.rowIcon}>{row.icon}</Text>
            <Text style={[styles.rowLabel, row.danger && styles.rowLabelDanger]}>{row.label}</Text>
            <View style={styles.rowRight}>
              {row.type === 'toggle' ? (
                <Switch
                  value={notifs}
                  onValueChange={handleNotifsToggle}
                  trackColor={{ false: COLORS.border, true: COLORS.purpleDark }}
                  thumbColor={COLORS.white}
                />
              ) : (
                <>
                  {row.value && <Text style={styles.rowValue}>{row.value}</Text>}
                  <Text style={styles.rowArrow}>›</Text>
                </>
              )}
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>AKINU .AI • Powered by Claude</Text>
        <Text style={styles.footerSub}>For production, proxy API calls through your backend.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 20, paddingBottom: 48 },
  profileCard: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  profileName: { fontSize: 18, fontWeight: '700', color: COLORS.white, marginBottom: 20 },
  statsRow: { flexDirection: 'row', alignItems: 'center' },
  stat: { alignItems: 'center', flex: 1 },
  statNum: { fontSize: 20, fontWeight: '700', color: COLORS.white },
  statLabel: { fontSize: 11, color: COLORS.textDim, marginTop: 2 },
  statDivider: { width: 1, height: 28, backgroundColor: COLORS.border },
  settingsList: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    gap: 14,
  },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: COLORS.border },
  rowIcon: { fontSize: 20 },
  rowLabel: { flex: 1, fontSize: 14, color: COLORS.textSecondary },
  rowLabelDanger: { color: COLORS.red },
  rowRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  rowValue: { fontSize: 13, color: COLORS.textDim },
  rowArrow: { fontSize: 20, color: COLORS.textDim },
  footer: { alignItems: 'center', gap: 4 },
  footerText: { fontSize: 12, color: COLORS.textDim },
  footerSub: { fontSize: 11, color: COLORS.textDim, opacity: 0.6, textAlign: 'center' },
});
