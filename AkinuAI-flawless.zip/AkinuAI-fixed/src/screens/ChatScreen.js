import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SYSTEM_PROMPT, API_URL, API_KEY } from '../constants';
import { TypingDots, MessageContent } from '../components';

export default function ChatScreen({ navigation, route }) {
  const initialPrompt = route?.params?.initialPrompt;
  const chatId = route?.params?.chatId;

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [apiKeyMissing, setApiKeyMissing] = useState(false);
  const listRef = useRef(null);
  const sentInitial = useRef(false);
  const chatKeyRef = useRef(chatId ? `chat_messages_${chatId}` : null);
  const messagesRef = useRef([]);

  // Keep messagesRef in sync so callbacks always have latest messages
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  // Detect missing API key on mount
  useEffect(() => {
    if (!API_KEY || API_KEY === 'sk-ant-api03-REPLACE_WITH_YOUR_KEY') {
      setApiKeyMissing(true);
    }
  }, []);

  // Load existing messages when resuming a chat
  useEffect(() => {
    if (!chatId) return;
    AsyncStorage.getItem(`chat_messages_${chatId}`)
      .then(raw => {
        if (raw) setMessages(JSON.parse(raw));
      })
      .catch(() => {});
  }, [chatId]);

  const scrollToBottom = useCallback(() => {
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }, []);

  const persistMessages = useCallback(async (updatedMessages, isFirstMessage) => {
    try {
      if (!chatKeyRef.current) {
        const newId = Date.now().toString();
        chatKeyRef.current = `chat_messages_${newId}`;

        const raw = await AsyncStorage.getItem('recent_chats');
        const existing = raw ? JSON.parse(raw) : [];
        const entry = {
          id: newId,
          title: updatedMessages[0]?.content?.slice(0, 60) ?? 'New Chat',
          timestamp: Date.now(),
        };
        await AsyncStorage.setItem(
          'recent_chats',
          JSON.stringify([entry, ...existing].slice(0, 20))
        );
      } else if (isFirstMessage) {
        const raw = await AsyncStorage.getItem('recent_chats');
        const existing = raw ? JSON.parse(raw) : [];
        const key = chatKeyRef.current.replace('chat_messages_', '');
        const updated = existing.map(e =>
          e.id === key ? { ...e, timestamp: Date.now() } : e
        );
        await AsyncStorage.setItem('recent_chats', JSON.stringify(updated));
      }

      await AsyncStorage.setItem(chatKeyRef.current, JSON.stringify(updatedMessages));
    } catch (_) {}
  }, []);

  const sendMessage = useCallback(async (text) => {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;
    if (text == null) setInput('');

    const currentMessages = messagesRef.current;

    if (apiKeyMissing) {
      const warnMsg = {
        role: 'assistant',
        content: '⚠️ No API key found. Add your Anthropic key to `.env` as `ANTHROPIC_API_KEY=sk-ant-...` and rebuild the app.',
        id: Date.now().toString(),
      };
      setMessages(prev => [
        ...prev,
        { role: 'user', content: msg, id: (Date.now() - 1).toString() },
        warnMsg,
      ]);
      return;
    }

    const isFirstMessage = currentMessages.length === 0;
    const userMsg = { role: 'user', content: msg, id: Date.now().toString() };
    const updated = [...currentMessages, userMsg];
    setMessages(updated);
    setLoading(true);
    scrollToBottom();

    await persistMessages(updated, isFirstMessage);

    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': API_KEY,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1024,
          system: SYSTEM_PROMPT,
          messages: updated.map(m => ({ role: m.role, content: m.content })),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data?.error?.message ?? `HTTP ${res.status}`);
      }

      const reply = data.content?.map(b => b.text || '').join('') || 'Sorry, try again.';
      const aiMsg = { role: 'assistant', content: reply, id: (Date.now() + 1).toString() };
      const withReply = [...updated, aiMsg];
      setMessages(withReply);
      await persistMessages(withReply, false);
    } catch (err) {
      const errMsg = {
        role: 'assistant',
        content: `⚠️ ${err.message || 'Connection error. Please check your internet and retry.'}`,
        id: (Date.now() + 1).toString(),
      };
      const withErr = [...updated, errMsg];
      setMessages(withErr);
      await persistMessages(withErr, false);
    } finally {
      setLoading(false);
      scrollToBottom();
    }
  }, [input, loading, apiKeyMissing, scrollToBottom, persistMessages]);

  // Send the initial prompt once (new chats only)
  useEffect(() => {
    if (!initialPrompt || sentInitial.current || chatId) return;
    const timer = setTimeout(() => {
      sentInitial.current = true;
      sendMessage(initialPrompt);
    }, 100);
    return () => clearTimeout(timer);
  }, [initialPrompt, chatId, sendMessage]);

  const renderMessage = ({ item }) => {
    const isUser = item.role === 'user';
    return (
      <View style={[styles.msgRow, isUser && styles.msgRowUser]}>
        {!isUser && (
          <LinearGradient colors={['#7c3aed', '#a78bfa']} style={styles.avatar}>
            <Text style={{ fontSize: 14 }}>⚡</Text>
          </LinearGradient>
        )}
        <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAI]}>
          <MessageContent text={item.content} />
        </View>
      </View>
    );
  };

  const keyboardOffset = Platform.OS === 'ios' ? 90 : 0;

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={keyboardOffset}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backArrow}>‹</Text>
        </TouchableOpacity>
        <LinearGradient colors={['#7c3aed', '#a78bfa']} style={styles.headerAvatar}>
          <Text style={{ fontSize: 18 }}>⚡</Text>
        </LinearGradient>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>AKINU .AI</Text>
          <Text style={styles.headerStatus}>
            {apiKeyMissing ? '⚠️ Setup required' : '● Online'}
          </Text>
        </View>
      </View>

      {/* API key warning banner */}
      {apiKeyMissing && (
        <View style={styles.warningBanner}>
          <Text style={styles.warningText}>
            🔑 Add your Anthropic API key to <Text style={styles.warningCode}>.env</Text> to start chatting.
          </Text>
        </View>
      )}

      {/* Messages */}
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={renderMessage}
        contentContainerStyle={styles.messageList}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={scrollToBottom}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>⚡</Text>
            <Text style={styles.emptyText}>What complex task{'\n'}can I tackle for you?</Text>
          </View>
        }
        ListFooterComponent={loading ? (
          <View style={styles.msgRow}>
            <LinearGradient colors={['#7c3aed', '#a78bfa']} style={styles.avatar}>
              <Text style={{ fontSize: 14 }}>⚡</Text>
            </LinearGradient>
            <TypingDots />
          </View>
        ) : null}
      />

      {/* Input bar */}
      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Message AKINU .AI..."
          placeholderTextColor={COLORS.textDim}
          multiline
          maxLength={2000}
          returnKeyType="send"
          onSubmitEditing={() => sendMessage()}
          blurOnSubmit={false}
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!input.trim() || loading) && styles.sendBtnDisabled]}
          onPress={() => sendMessage()}
          disabled={!input.trim() || loading}
          activeOpacity={0.8}
        >
          {loading
            ? <ActivityIndicator size="small" color={COLORS.white} />
            : <Text style={styles.sendIcon}>↑</Text>
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    backgroundColor: COLORS.bgPanel,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  backBtn: { padding: 4 },
  backArrow: { fontSize: 28, color: COLORS.purple, lineHeight: 28 },
  headerAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: { fontSize: 15, fontWeight: '600', color: COLORS.white },
  headerStatus: { fontSize: 11, color: COLORS.green },
  warningBanner: {
    backgroundColor: '#2a1a00',
    borderBottomWidth: 1,
    borderBottomColor: '#5a3a00',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  warningText: { fontSize: 12, color: '#fbbf24', lineHeight: 18 },
  warningCode: { fontFamily: 'monospace', color: '#fde68a' },
  messageList: { padding: 16, gap: 14, paddingBottom: 8 },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginBottom: 4 },
  msgRowUser: { flexDirection: 'row-reverse' },
  avatar: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  bubble: { maxWidth: '80%', borderRadius: 18, padding: 12 },
  bubbleUser: { backgroundColor: COLORS.userBubble, borderBottomRightRadius: 4 },
  bubbleAI: { backgroundColor: COLORS.aiBubble, borderBottomLeftRadius: 4 },
  emptyState: { alignItems: 'center', marginTop: 80 },
  emptyIcon: { fontSize: 48, marginBottom: 16 },
  emptyText: { fontSize: 16, color: COLORS.textMuted, textAlign: 'center', lineHeight: 24 },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
    padding: 12,
    paddingBottom: Platform.OS === 'ios' ? 28 : 14,
    backgroundColor: COLORS.bgDark,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  input: {
    flex: 1,
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    borderRadius: 22,
    color: COLORS.textPrimary,
    fontSize: 14,
    paddingHorizontal: 16,
    paddingVertical: 10,
    maxHeight: 100,
    lineHeight: 20,
  },
  sendBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: COLORS.purpleDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendBtnDisabled: { backgroundColor: COLORS.border },
  sendIcon: { fontSize: 18, color: COLORS.white, fontWeight: '700' },
});
