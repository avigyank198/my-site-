import Constants from 'expo-constants';

export const COLORS = {
  bg: '#080818',
  bgCard: '#111127',
  bgDark: '#0a0a18',
  bgPanel: '#0f0f23',
  border: '#1e1e3a',
  borderLight: '#2a2a4a',
  purple: '#a78bfa',
  purpleDark: '#7c3aed',
  purpleDeep: '#4c1d95',
  white: '#ffffff',
  textPrimary: '#e2e8f0',
  textSecondary: '#d4d4e8',
  textMuted: '#7c7c99',
  textDim: '#555555',
  green: '#4ade80',
  red: '#f87171',
  userBubble: '#7c3aed',
  aiBubble: '#1e1e3a',
  codeBg: '#0a0a18',
  codeHeader: '#12122a',
};

export const SYSTEM_PROMPT = `You are AKINU .AI, a powerful mobile AI assistant. You help users with complex tasks including building websites, writing code, creative writing, analysis, and more. Keep responses concise and well-formatted for mobile screens. Use emojis naturally. When generating code, wrap it in triple backticks with the language name.`;

export const API_URL = 'https://api.anthropic.com/v1/messages';

// API key loaded from .env via app.config.js → expo-constants.
// Never hardcode your key here. Add it to your .env file instead.
export const API_KEY = Constants.expoConfig?.extra?.anthropicApiKey ?? '';

export const QUICK_ACTIONS = [
  { icon: '🌐', label: 'Build Website', prompt: 'Build me a modern landing page with HTML, CSS and JS. Make it beautiful and complete.' },
  { icon: '💻', label: 'Write Code', prompt: 'Write me a Python script to automate file organization by type and date.' },
  { icon: '✍️', label: 'Write Content', prompt: 'Write a compelling product description for an AI-powered mobile app startup.' },
  { icon: '🧠', label: 'Brainstorm', prompt: 'Give me 10 innovative app ideas for 2025 with brief descriptions.' },
  { icon: '📊', label: 'Analyze Data', prompt: 'Explain how to analyze and visualize sales data using Python pandas and matplotlib.' },
  { icon: '🎨', label: 'Design Help', prompt: 'Give me a complete color palette and typography guide for a modern fintech mobile app.' },
];

export const EXPLORE_CATEGORIES = [
  {
    icon: '🌐',
    title: 'Web Development',
    items: ['Portfolio site', 'E-commerce store', 'SaaS landing page', 'Blog platform', 'Admin dashboard'],
  },
  {
    icon: '📱',
    title: 'Mobile & Apps',
    items: ['App UI design', 'React Native code', 'Flutter widgets', 'App store copy', 'Push notifications'],
  },
  {
    icon: '🤖',
    title: 'AI & Automation',
    items: ['Python scripts', 'Data pipelines', 'API integrations', 'Chatbot flows', 'Web scrapers'],
  },
  {
    icon: '✍️',
    title: 'Content & Copy',
    items: ['Blog articles', 'Ad campaigns', 'Email sequences', 'Social posts', 'Product descriptions'],
  },
];
