import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Animated,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../constants';

// ── Typing indicator ──────────────────────────────────────────────────
export function TypingDots() {
  // useRef ensures Animated.Values are created once and survive re-renders
  const dots = React.useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  React.useEffect(() => {
    const animations = dots.map((dot, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 200),
          Animated.timing(dot, { toValue: -6, duration: 300, useNativeDriver: true }),
          Animated.timing(dot, { toValue: 0, duration: 300, useNativeDriver: true }),
          Animated.delay(600),
        ])
      )
    );
    animations.forEach(a => a.start());
    return () => animations.forEach(a => a.stop());
  }, []);

  return (
    <View style={styles.dotsContainer}>
      {dots.map((dot, i) => (
        <Animated.View
          key={i}
          style={[styles.dot, { transform: [{ translateY: dot }] }]}
        />
      ))}
    </View>
  );
}

// ── Code block ────────────────────────────────────────────────────────
export function CodeBlock({ lang, code }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await Clipboard.setStringAsync(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <View style={styles.codeBlock}>
      <View style={styles.codeHeader}>
        <Text style={styles.codeLang}>{lang || 'code'}</Text>
        <TouchableOpacity onPress={handleCopy}>
          <Text style={[styles.copyBtn, copied && styles.copyBtnDone]}>
            {copied ? '✓ Copied' : 'Copy'}
          </Text>
        </TouchableOpacity>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <Text style={styles.codeText}>{code.trim()}</Text>
      </ScrollView>
    </View>
  );
}

// ── Message renderer (text + code blocks) ────────────────────────────
export function MessageContent({ text }) {
  const parts = [];
  const regex = /```(\w*)\n?([\s\S]*?)```/g;
  let last = 0;
  let m;

  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) {
      parts.push({ type: 'text', content: text.slice(last, m.index) });
    }
    parts.push({ type: 'code', lang: m[1], content: m[2] });
    last = m.index + m[0].length;
  }
  if (last < text.length) {
    parts.push({ type: 'text', content: text.slice(last) });
  }

  return (
    <View>
      {parts.map((p, i) =>
        p.type === 'code' ? (
          <CodeBlock key={i} lang={p.lang} code={p.content} />
        ) : (
          <Text key={i} style={styles.messageText}>
            {p.content}
          </Text>
        )
      )}
    </View>
  );
}

// ── Quick action chip ─────────────────────────────────────────────────
export function QuickActionCard({ icon, label, onPress }) {
  return (
    <TouchableOpacity style={styles.qaCard} onPress={onPress} activeOpacity={0.7}>
      <Text style={styles.qaIcon}>{icon}</Text>
      <Text style={styles.qaLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

// ── Section header ────────────────────────────────────────────────────
export function SectionLabel({ text }) {
  return <Text style={styles.sectionLabel}>{text}</Text>;
}

const styles = StyleSheet.create({
  // Typing dots
  dotsContainer: {
    flexDirection: 'row',
    gap: 5,
    paddingHorizontal: 14,
    paddingVertical: 12,
    backgroundColor: COLORS.aiBubble,
    borderRadius: 18,
    borderBottomLeftRadius: 4,
    alignSelf: 'flex-start',
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: COLORS.purple,
  },
  // Code block
  codeBlock: {
    marginTop: 8,
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.borderLight,
  },
  codeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.codeHeader,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  codeLang: {
    fontSize: 11,
    color: COLORS.textMuted,
    fontFamily: 'monospace',
  },
  copyBtn: {
    fontSize: 11,
    color: COLORS.purple,
  },
  copyBtnDone: {
    color: COLORS.green,
  },
  codeText: {
    fontSize: 12,
    color: '#c4c4e0',
    fontFamily: 'monospace',
    lineHeight: 18,
    padding: 12,
    backgroundColor: COLORS.codeBg,
  },
  // Message
  messageText: {
    fontSize: 14,
    color: COLORS.white,
    lineHeight: 21,
  },
  // Quick action
  qaCard: {
    flex: 1,
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 14,
    padding: 14,
    margin: 4,
  },
  qaIcon: { fontSize: 22, marginBottom: 6 },
  qaLabel: { fontSize: 13, color: COLORS.textSecondary, fontWeight: '500' },
  // Section label
  sectionLabel: {
    fontSize: 11,
    color: COLORS.textDim,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 10,
    marginTop: 4,
  },
});
