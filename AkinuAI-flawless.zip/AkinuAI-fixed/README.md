# AKINU .AI

A powerful AI assistant mobile app built with React Native + Expo, powered by Claude (Anthropic).

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Add your API key
Edit `.env` and replace the placeholder:
```
ANTHROPIC_API_KEY=sk-ant-api03-YOUR_REAL_KEY_HERE
```

### 3. Run locally
```bash
npm start          # Expo Go (QR code)
npm run android    # Android emulator
npm run ios        # iOS simulator (Mac only)
```

---

## Build APK (Android)

### Prerequisites
- [Expo account](https://expo.dev) (free)
- EAS CLI: `npm install -g eas-cli`
- Log in: `eas login`

### One-time project setup
```bash
eas init           # Links project to your Expo account (generates projectId)
```
Copy the `projectId` from the output and add it to `app.config.js` → `extra.eas.projectId`.

### Add your API key as an EAS Secret (secure — not baked into code)
```bash
eas secret:create --scope project --name ANTHROPIC_API_KEY --value sk-ant-api03-YOUR_KEY
```

### Build the APK
```bash
npm run build:apk
# or directly:
eas build --platform android --profile preview
```

EAS will build in the cloud and give you a download link for the `.apk` file.

### Build AAB (Google Play Store)
```bash
npm run build:aab
```

---

## Security note
The API key is loaded at **build time** from EAS Secrets into the app bundle.  
For a public production app, route API calls through your own backend server instead.

---

## Tech stack
- React Native 0.74 + Expo SDK 51
- React Navigation (Bottom Tabs + Stack)
- AsyncStorage (chat persistence)
- Anthropic Claude API (claude-sonnet-4-6)
