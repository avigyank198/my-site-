// app.config.js — dynamic config that reads from .env
// Local dev:  add your key to .env as ANTHROPIC_API_KEY=sk-ant-api03-...
// EAS build:  set the secret in your EAS dashboard under "Secrets"
//             https://expo.dev/accounts/[username]/projects/[slug]/secrets

module.exports = ({ config }) => ({
  ...config,
  extra: {
    anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? '',
    eas: {
      projectId: config.extra?.eas?.projectId ?? '',
    },
  },
});
